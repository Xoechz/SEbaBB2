#!/bin/bash
../bin/TestVector;
echo;
../bin/TestStack;
echo;
../bin/TestQueue;